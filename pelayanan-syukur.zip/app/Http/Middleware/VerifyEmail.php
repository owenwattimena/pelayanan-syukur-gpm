<?php

namespace App\Http\Middleware;

use App\Helpers\JsonFormatter;
use Closure;
use Illuminate\Auth\Middleware\Authenticate;
class VerifyEmail extends Authenticate
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle($request, Closure $next, ...$guards)
    {
        $user = $request->user();
        if ($user) {
            if($user->email_verified_at == null)
            {
                return JsonFormatter::error("Email belum diverifikasi.", code: 403);
            }
        }
        return $next($request);
    }
}

<?php $__env->startSection('style'); ?>
<link href="assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title', 'Pengurus Unit'); ?>
<?php $__env->startSection('subtitle', 'Daftar Pengurus Unit'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">

        <div class="text-end">
            <button class="btn btn-sm btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#tambahPengurusModal">Tambah</button>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="tambahPengurusModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Tambah Pengurus Unit</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('pengurus-unit.simpan')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="inputNama" class="form-label">Nama Lengkap</label>
                                <input required type="text" class="form-control" id="inputNama" name="nama_lengkap">
                            </div>
                            <div class="mb-3">
                                <label for="inputEmail" class="form-label">Email</label>
                                <input required type="email" class="form-control" id="inputEmail" name="email">
                            </div>
                            <div class="mb-3">
                                <label for="inputTelp" class="form-label">No. Telp</label>
                                <input required type="text" class="form-control" id="inputTelp" name="telepon">
                            </div>
                            <div class="mb-3">
                                <label for="selectUnit" class="form-label">Unit</label>
                                <select required class="form-control" id="selectUnit" name="id_unit">
                                    <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_unit); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="inputUsername" class="form-label">Username</label>
                                <input required type="text" class="form-control" id="inputUsername" name="username">
                            </div>
                            <div class="mb-3">
                                <label for="inputPassword" class="form-label">Password</label>
                                <input required type="password" class="form-control" id="inputPassword" name="password">
                            </div>
                            <button type="submit" class="btn btn-primary w-100">Simpan</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="table-responsive">
            <table id="table" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>No. Telp</th>
                        <th>Sektor</th>
                        <th>Unit</th>
                        <th>Username</th>
                        
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$key); ?></td>
                        <td><?php echo e($user->nama_lengkap); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->telepon); ?></td>
                        <td><?php echo e($user->unit->first()->sektor->nama_sektor); ?></td>
                        <td><?php echo e($user->unit->first()->nama_unit); ?></td>
                        <td><?php echo e($user->username); ?></td>
                        
                        <td>
                            <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#ubahPengurusModal<?php echo e($user->id); ?>">Ubah</button>
                            
                            <!-- Modal -->
                            <div class="modal fade" id="ubahPengurusModal<?php echo e($user->id); ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Tambah Pengurus Unit</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(route('pengurus-unit.ubah', $user->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('put'); ?>
                                                <div class="mb-3">
                                                    <label for="inputNama" class="form-label">Nama Lengkap</label>
                                                    <input required type="text" class="form-control" id="inputNama" name="nama_lengkap" value="<?php echo e($user->nama_lengkap); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="inputEmail" class="form-label">Email</label>
                                                    <input required type="email" class="form-control" id="inputEmail" name="email" value="<?php echo e($user->email); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="inputTelp" class="form-label">No. Telp</label>
                                                    <input required type="text" class="form-control" id="inputTelp" name="telepon" value="<?php echo e($user->telepon); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="selectUnit" class="form-label">Unit</label>
                                                    <select required class="form-control" id="selectUnit" name="id_unit">
                                                        <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemUnit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($itemUnit->id); ?>" <?php echo e($itemUnit->id == $user->id_unit ? 'selected' : ''); ?>><?php echo e($itemUnit->nama_unit); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>

                                                <div class="mb-3">
                                                    <label for="inputUsername" class="form-label">Username</label>
                                                    <input required type="text" class="form-control" id="inputUsername" name="username" value="<?php echo e($user->username); ?>">
                                                </div>
                                                <div class="mb-3">
                                                    <label for="inputPassword" class="form-label">Password</label>
                                                    <input type="password" class="form-control" id="inputPassword" name="password">
                                                </div>
                                                <button type="submit" class="btn btn-primary w-100">Simpan</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <form action="<?php echo e(route('pengurus-unit.hapus', $user->id)); ?>" method="post" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button onclick="return confirm('Yakin ingin menghapus data?')" class="btn btn-danger btn-sm">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script src="assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>

<script>
    $(document).ready(function() {
        $('#table').DataTable();
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon-php8\www\pelayanan-syukur\resources\views/verifikasi/index.blade.php ENDPATH**/ ?>
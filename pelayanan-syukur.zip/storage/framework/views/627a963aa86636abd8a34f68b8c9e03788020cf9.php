<?php $__env->startSection('style'); ?>
<link href="assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title', 'Pengaturan'); ?>
<?php $__env->startSection('subtitle', 'Data pengaturan'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <form action="<?php echo e(route('pengaturan.save')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="col-md-12">
                <label for="inputPengaturan" class="form-label">Nama Jemaat</label>
                <input class="form-control" id="inputPengaturan" name="nama_jemaat" required value="<?php echo e($pengaturan->nama_jemaat ?? ''); ?>">
            </div>
            <button type="submit" class="btn btn-primary mt-3">Simpan</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="assets/plugins/datatable/js/jquery.dataTables.min.js"></script>

<script>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon-php8\www\pelayanan-syukur\resources\views/pengaturan/index.blade.php ENDPATH**/ ?>
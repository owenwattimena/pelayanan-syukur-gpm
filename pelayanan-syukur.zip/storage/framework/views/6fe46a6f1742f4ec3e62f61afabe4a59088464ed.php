
<?php $__env->startSection('style'); ?>
<link href="assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title', 'Jemaat'); ?>
<?php $__env->startSection('subtitle', 'Daftar Jemaat'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div class="text-end">
            <button class="btn btn-sm mb-5 btn-primary rounded-0" data-bs-toggle="modal" data-bs-target="#exampleModal">Tambah</button>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <form action="<?php echo e(route('jemaat.tambah')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Tambah Kelahiran</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="col-md-12">
                                <label for="inputNoKK" class="form-label">No KK</label>
                                <input type="text" class="form-control" id="inputNoKK" name="no_kk" placeholder="Nomor KK" required>
                            </div>
                            <div class="col-md-12">
                                <label for="inputNamaLengkap" class="form-label">Nama Lengkap</label>
                                <input type="text" class="form-control" id="inputNamaLengkap" name="nama_lengkap" placeholder="Nama Lengkap" required>
                            </div>
                            <div class="col-md-12">
                                <label for="selectStatusKeluarga" class="form-label">Status Keluarga</label>
                                <select type="date" class="form-control" id="selectStatusKeluarga" name="status_keluarga" required>
                                    <?php $__currentLoopData = ["Kepala keluarga", "Istri", "Suami", "Anak", "Cucu", "Keponakan", "Orang Tua", "Mertua", "Menantu", "Kakak", "Adik", "Ipar", "Om/Tente", "Sepupu", "Keluarga Lain", "Penghuni Kost", "Lainnya"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-12">
                                <label for="selectJenisKelamin" class="form-label">Jenis Kelamin</label>
                                <select type="date" class="form-control" id="selectJenisKelamin" name="jenis_kelamin" required>
                                    <?php $__currentLoopData = ["l" => "Laki-laki", "p"=>"Perempuan"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-12">
                                <label for="inputTempatLahir" class="form-label">Tempat Lahir</label>
                                <input type="text" class="form-control" id="inputTempatLahir" name="tempat_lahir" placeholder="Tempat Lahir" required>
                            </div>
                            <div class="col-md-12">
                                <label for="inputTanggalLahir" class="form-label">Tanggal Lahir</label>
                                <input type="date" class="form-control" id="inputTanggalLahir" name="tanggal_lahir" placeholder="Tanggal" required>
                            </div>
                            <div class="col-md-12">
                                <label for="selectStatusDomisili" class="form-label">Status Domisili</label>
                                <select type="date" class="form-control" id="selectStatusDomisili" name="status_domisili" required>
                                    <?php $__currentLoopData = ["Aggota tetap GPM", "Anggota tidak tetap GPM"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-12">
                                <label for="selectStatusMenikah" class="form-label">Status Menikah</label>
                                <select type="date" class="form-control" id="selectStatusMenikah" name="status_menikah" required>
                                    <?php $__currentLoopData = ["Belum Menikah", "Menikah"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-12">
                                <label for="inputTanggalMenikah" class="form-label">Tanggal Menikah</label>
                                <input type="date" class="form-control" id="inputTanggalMenikah" name="tanggal_menikah" placeholder="Tanggal">
                            </div>
                            <div class="col-md-12">
                                <label for="inputAlamat" class="form-label">Alamat</label>
                                <textarea type="text" class="form-control" id="inputAlamat" name="alamat" placeholder="Alamat" required></textarea>
                            </div>
                            <div class="col-md-12">
                                <label for="selectIdUnit" class="form-label">Unit</label>
                                <select type="date" class="form-control" id="selectIdUnit" name="id_unit" required>
                                    <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_unit); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="table-responsive">
            <table id="table" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>No KK</th>
                        <th>Nama Lengkap</th>
                        <th>Status Keluarga</th>
                        <th>Jenis Kelamin</th>
                        <th>TTL</th>
                        <th>Status Domisili</th>
                        <th>Status Menikah</th>
                        <th>Tanggal Menikah</th>
                        <th>Alamat</th>
                        <th>Unit</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 0;
                    ?>
                    <?php $__currentLoopData = $jemaat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$no); ?></td>
                        <td><?php echo e($row->no_kk); ?></td>
                        <td><?php echo e($row->nama_lengkap); ?></td>
                        <td><?php echo e($row->status_keluarga); ?></td>
                        <td><?php echo e($row->jenis_kelamin); ?></td>
                        <td><?php echo e($row->tempat_lahir); ?>, <?php echo e($row->tanggal_lahir); ?></td>
                        <td><?php echo e($row->status_domisili); ?></td>
                        <td><?php echo e($row->status_menikah ? "Menikah" : "Belum Menikah"); ?></td>
                        <td><?php echo e($row->tanggal_menikah); ?></td>
                        <td><?php echo e($row->alamat); ?></td>
                        <td><?php echo e($row->unit->nama_unit); ?></td>
                        <td>
                            <button class="btn btn-sm btn-warning rounded" data-bs-toggle="modal" data-bs-target="#ubahDataModal-<?php echo e($row->id); ?>"><i class="bx bx-edit"></i></button>

                            <form action="<?php echo e(route('jemaat.hapus', $row->id)); ?>" method="post" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button onclick="return confirm('Yakin ingin menghapus data?')" class="btn btn-danger btn-sm">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <!-- Modal -->
                    <div class="modal fade" id="ubahDataModal-<?php echo e($row->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <form action="<?php echo e(route('jemaat.ubah', $row->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Ubah Kelahiran</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="col-md-12">
                                            <label for="inputNoKK" class="form-label">No KK</label>
                                            <input type="text" class="form-control" id="inputNoKK" name="no_kk" placeholder="Nomor KK" value="<?php echo e($row->no_kk); ?>" required>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="inputNamaLengkap" class="form-label">Nama Lengkap</label>
                                            <input type="text" class="form-control" id="inputNamaLengkap" name="nama_lengkap" placeholder="Nama Lengkap" value="<?php echo e($row->nama_lengkap); ?>" required>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="selectStatusKeluarga" class="form-label">Status Keluarga</label>
                                            <select type="date" class="form-control" id="selectStatusKeluarga" name="status_keluarga" required>
                                                <?php $__currentLoopData = ["Kepala keluarga", "Istri", "Suami", "Anak", "Cucu", "Keponakan", "Orang Tua", "Mertua", "Menantu", "Kakak", "Adik", "Ipar", "Om/Tente", "Sepupu", "Keluarga Lain", "Penghuni Kost", "Lainnya"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item); ?>" <?php echo e($row->status_keluarga == $item ? "selected" : ""); ?>><?php echo e($item); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="selectJenisKelamin" class="form-label">Jenis Kelamin</label>
                                            <select type="date" class="form-control" id="selectJenisKelamin" name="jenis_kelamin" required>
                                                <?php $__currentLoopData = ["l" => "Laki-laki", "p"=>"Perempuan"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php echo e($key == $row->jenis_kelamin ? "selected" : ""); ?>><?php echo e($item); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="inputTempatLahir" class="form-label">Tempat Lahir</label>
                                            <input type="text" class="form-control" id="inputTempatLahir" name="tempat_lahir" placeholder="Tempat Lahir" value="<?php echo e($row->tempat_lahir); ?>" required>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="inputTanggalLahir" class="form-label">Tanggal Lahir</label>
                                            <input type="date" class="form-control" id="inputTanggalLahir" name="tanggal_lahir" placeholder="Tanggal" value="<?php echo e($row->tanggal_lahir); ?>" required>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="selectStatusDomisili" class="form-label">Status Domisili</label>
                                            <select type="date" class="form-control" id="selectStatusDomisili" name="status_domisili" required>
                                                <?php $__currentLoopData = ["Aggota tetap GPM", "Anggota tidak tetap GPM"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item); ?>" <?php echo e($item == $row->status_domisili ? "selected" : ""); ?>><?php echo e($item); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="selectStatusMenikah" class="form-label">Status Menikah</label>
                                            <select type="date" class="form-control" id="selectStatusMenikah" name="status_menikah" required>
                                                <?php $__currentLoopData = ["Belum Menikah", "Menikah"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>" <?php echo e($key == $row->status_menikah ? "selected" : ""); ?>><?php echo e($item); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="inputTanggalMenikah" class="form-label">Tanggal Menikah</label>
                                            <input type="date" class="form-control" id="inputTanggalMenikah" name="tanggal_menikah" value="<?php echo e($row->tanggal_menikah); ?>" placeholder="Tanggal">
                                        </div>
                                        <div class="col-md-12">
                                            <label for="inputAlamat" class="form-label">Alamat</label>
                                            <textarea type="text" class="form-control" id="inputAlamat" name="alamat" placeholder="Alamat" required><?php echo e($row->alamat); ?></textarea>
                                        </div>
                                        <div class="col-md-12">
                                            <label for="selectIdUnit" class="form-label">Unit</label>
                                            <select type="date" class="form-control" id="selectIdUnit" name="id_unit" required>
                                                <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $row->id_unit ? "selected" : ""); ?>><?php echo e($item->nama_unit); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                        <button type="submit" class="btn btn-primary">Simpan</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script src="assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>

<script>
    $(document).ready(function() {
        $('#table').DataTable();
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon-php8\www\pelayanan-syukur\resources\views/jemaat/index.blade.php ENDPATH**/ ?>
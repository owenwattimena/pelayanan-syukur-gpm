
<?php $__env->startSection('style'); ?>
<link href="assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('subtitle', 'Selamat datang ' . auth()->user()->nama_lengkap); ?>

<?php $__env->startSection('content'); ?>
<?php if(auth()->guard('admin')->user()->role == 'admin_jemaat'): ?>
<div class="card radius-10">
    <div class="card-content">
        <div class="row row-group row-cols-1 row-cols-xl-4">
            <div class="col">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div>
                            <p class="mb-0">Total Sektor</p>
                            <h4 class="mb-0 text-secondary"><?php echo e($totalSektor); ?></h4>
                        </div>
                        <div class="ms-auto"><i class="bx bx-map-alt font-35 text-secondary"></i>
                        </div>
                    </div>
                    <div class="progress radius-10 my-2" style="height:4px;">
                        <div class="progress-bar bg-secondary" role="progressbar" style="width: 100%"></div>
                    </div>
                    <p class="mb-0 font-13">Data total sektor dalam jemaat</p>
                </div>
            </div>
            <div class="col">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div>
                            <p class="mb-0">Total Unit</p>
                            <h4 class="mb-0 text-secondary"><?php echo e($totalUnit); ?></h4>
                        </div>
                        <div class="ms-auto"><i class="bx bx-grid font-35 text-secondary"></i>
                        </div>
                    </div>
                    <div class="progress radius-10 my-2" style="height:4px;">
                        <div class="progress-bar bg-secondary" role="progressbar" style="width: 100%"></div>
                    </div>
                    <p class="mb-0 font-13">Data total unit dalam jemaat</p>
                </div>
            </div>
            <div class="col">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div>
                            <p class="mb-0">Pengurus Sektor</p>
                            <h4 class="mb-0 text-secondary"><?php echo e($totalPengurusSektor); ?></h4>
                        </div>
                        <div class="ms-auto"><i class="bx bx-user font-35 text-secondary"></i>
                        </div>
                    </div>
                    <div class="progress radius-10 my-2" style="height:4px;">
                        <div class="progress-bar bg-secondary" role="progressbar" style="width: 100%"></div>
                    </div>
                    <p class="mb-0 font-13">Data total pengurus sektor dalam jemaat</p>
                </div>
            </div>
            <div class="col">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div>
                            <p class="mb-0">Pengurus Unit</p>
                            <h4 class="mb-0 text-secondary"><?php echo e($totalPengurusUnit); ?></h4>
                        </div>
                        <div class="ms-auto"><i class="bx bx-male font-35 text-secondary"></i>
                        </div>
                    </div>
                    <div class="progress radius-10 my-2" style="height:4px;">
                        <div class="progress-bar bg-secondary" role="progressbar" style="width: 100%"></div>
                    </div>
                    <p class="mb-0 font-13">Data total pengurus unit dalam jemaat</p>
                </div>
            </div>
            
        </div>
    </div>
</div>
<?php else: ?>
<div class="row">
    <div class="col-xl-6">
<div class="card radius-10">
    <div class="card-content">
            <div class="row row-group row-cols-1 row-cols-xl-2">
                <div class="col">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                                <p class="mb-0">Total Unit Sektor</p>
                                <h4 class="mb-0 text-secondary"><?php echo e($totalUnit); ?></h4>
                            </div>
                            <div class="ms-auto"><i class="bx bx-grid font-35 text-secondary"></i>
                            </div>
                        </div>
                        <div class="progress radius-10 my-2" style="height:4px;">
                            <div class="progress-bar bg-secondary" role="progressbar" style="width: 100%"></div>
                        </div>
                        <p class="mb-0 font-13">Data total sektor dalam jemaat</p>
                    </div>
                </div>
                <div class="col">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div>
                                <p class="mb-0">Pengurus Unit</p>
                                <h4 class="mb-0 text-secondary"><?php echo e($totalPengurusUnit); ?></h4>
                            </div>
                            <div class="ms-auto"><i class="bx bx-male font-35 text-secondary"></i>
                            </div>
                        </div>
                        <div class="progress radius-10 my-2" style="height:4px;">
                            <div class="progress-bar bg-secondary" role="progressbar" style="width: 100%"></div>
                        </div>
                        <p class="mb-0 font-13">Data total pengurus unit dalam jemaat</p>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script src="assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>

<script>
    $(document).ready(function() {
        $('#table').DataTable();
    });

</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon-php8\www\pelayanan-syukur\resources\views/home/index.blade.php ENDPATH**/ ?>
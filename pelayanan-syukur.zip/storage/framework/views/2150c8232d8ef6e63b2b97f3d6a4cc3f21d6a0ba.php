
<?php $__env->startSection('style'); ?>
<link href="assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>


<?php $__env->startSection('title', 'Pelayanan Pernikahan'); ?>
<?php $__env->startSection('subtitle', 'Daftar Pelayanan Pernikahan'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <div class="row">
            <form action="">
                <div class="input-group w-30 mb-3">
                    <select class="form-control" name="month">
                        <?php for($i=1; $i<=12; $i++): ?>
                        <option value="<?php echo e($i); ?>" <?php echo e($i==$month? 'selected' :''); ?>><?php echo e($i); ?></option>
                        <?php endfor; ?>
                    </select>
                    <button class="btn btn-outline-secondary" type="submit" id="button-addon2">Cari</button>
                </div>
            </form>
        </div>
        <div class="table-responsive">
            <table id="table" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th>Nama Pria</th>
                        <th>Nama Wanita</th>
                        <th>Tanggal Pernikahan</th>
                        <th>Ulang Tahun Ke-</th>
                        <th>Unit</th>
                        <th>Alamat</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pernikahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->suami); ?></td>
                        <td><?php echo e($item->istri); ?></td>
                        <td><?php echo e($item->tanggal_menikah); ?></td>
                        <td><?php echo e($item->usia); ?></td>
                        <td><?php echo e($item->nama_unit); ?></td>
                        <td><?php echo e($item->alamat); ?></td>
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
<script src="assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>

<script>
    $(document).ready(function() {
        $('#table').DataTable();
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon-php8\www\pelayanan-syukur\resources\views/pelayanan-pernikahan/index.blade.php ENDPATH**/ ?>